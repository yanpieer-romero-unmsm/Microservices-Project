package com.springboot.app.gateway;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringbootServiceGatewayServerApplicationTests {

	@Test
	void contextLoads() {
	}

}
